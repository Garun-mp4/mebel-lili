@echo off
cd /d "%~dp0"
node server.mjs
pause
